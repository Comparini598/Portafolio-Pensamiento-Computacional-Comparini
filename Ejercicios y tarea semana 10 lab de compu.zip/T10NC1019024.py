print("Semana 10, ejercicio signo zodiacal")
#Natalia Comparini 1019024
día=int(input("Ingresa la fecha en que naciste"))
mes=int(input("ingresa el mes en el que naciste"))

if día<1 or día>31:
    if mes<1 or mes>12:
        print("El valor ingesado es inválido")

if mes==1:
    if día<20:
        print("Eres capricornio")
    else:
        print("Eres acuario")

if mes==2:
    if día<19:
        print("Eres acuario")
    else:
        print("Eres piscis")
    
elif mes==3:
    if día<21:
        print("Eres piscis")
    else:
        print("Eres aries")
elif mes==4:
    if día<20:
        print("Eres aries")
    else:
        print("Eres tauro")
elif mes ==5:
    if día<21:
        print("Eres tauro")
    else:
        print("Eres géminis")
elif mes==6:
    if día<21:
        print("Eres géminis")
    else:
        print("Eres cáncer")
elif mes==7:
    if día<24:
        print("Eres cáncer")
    else:
        print("Eres leo")
elif mes==8:
    if día<23:
        print("Eres leo")
    else:
        print("Eres virgo")
elif mes==9:
    if día<23:
        print("Eres virgo")
    else:
        print("Eres libra")
elif mes==10:
    if día<23:
        print("Eres libra")
    else:
        print("Eres escorpio")
elif mes==11:
    if día<22:
        print("Eres escorpio")
    else:
        print("Eres sagitario")
elif mes==12:
    if día<23:
        print("Eres sagitario")
    else:
        print("Eres capricornio")



