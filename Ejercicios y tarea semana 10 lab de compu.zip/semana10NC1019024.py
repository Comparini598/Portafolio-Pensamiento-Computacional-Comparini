#Natalia Comparini 1019024
print("Ejercicio semana #10, meses del año")
númerodemes=int(input("Ingresa el número"))

if númerodemes<1 or númerodemes>12:
    print("El número que ingresaste es inválido")
else:
    if númerodemes==1:
        print("El mes es enero")
    elif númerodemes==2:
        print("El mes es febrero")
    elif númerodemes==3:
        print("El mes es marzo")
    elif númerodemes==4:
        print("El mes es abril")
    elif númerodemes==5:
        print("El mes es mayo")
    elif númerodemes==6:
        print("El mes es junio, el mejor mes")
    elif númerodemes==7:
        print("El mes es julio")
    elif númerodemes==8:
        print("El mes es agosto")
    elif númerodemes==9:
        print("El mes es septiembre")
    elif númerodemes==10:
        print("El mes es octubre")
    elif númerodemes==11:
        print("El mes es noviembre")
    elif númerodemes==12:
        print("El mes es diciembre")

#con match y case
match(númerodemes):
    case 1:
        print("Mes=enero")
    case 2:
        print("Mes=febrero")
    case 3:
        print("Mes=marzo")
    case 4:
        print("Mes=abril")
    case 5:
        print("Mes=mayo")
    case 6:
        print("Mes=junio")
    case 7:
        print("Mes=julio")
    case 8:
        print("Mes=agosto")
    case 9:
        print("Mes=septiembre")
    case 10:
        print("Mes=octubre")
    case 11:
        print("Mes=noviembre")
    case 12:
        print("Mes=diciembre")





