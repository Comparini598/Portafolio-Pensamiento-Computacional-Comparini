print("Semana 10, tercer ejercicio")
#Natalia Comparini 1019024
a = int(input("Ingrese un primer número mayor a 0: "))
b = int(input("Ingrese un segundo número mayor a 0: "))
c = int(input("Ingrese un tercer número mayor a 0: "))

if(a<= 0 or b<= 0 or c<= 0):
    print("Error: Ingrese un primero número mayor a 0")

if(a>b):
    if(a>c):
        print("A es el mayor")
else:
    if(a==c):
        print("A es mayor que B, A es igual a C")
    else:
        print("A es mayor que B, A es menor que C")

    if (a == b):
        if (a > c):
            print("A es mayor que B y mayor que C")