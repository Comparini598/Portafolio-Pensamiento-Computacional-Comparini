#Natalia Comparini, 1019024
print("Ejercicio 2, semana 11")

num1=int(input("ingresa un valor mayor a 0\n"))
a=0
b=0
c=0
i=0

if (num1<=0):
    print("El número ingresado es inválido")
else:
    while i<num1:
        a=a + 1/1
        i=i+1
        print("El resultado del inciso a es:",+a)

    while i<num1:
        b=b +1/2**i
        i=i+1
        print("El resultado del inciso b es:", +b)

    x=int(input("Ingresa un valor I\n"))
    a1=int(input("Ingresa un valor II\n"))
    n3=int(input("Ingresa un valor III\n"))

    for i in range (0, n3 + 1):
        c=c+(x**i)+a1**(n3-i)
        print("El resultado del inciso c es:", +c)


