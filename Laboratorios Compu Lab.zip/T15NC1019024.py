def menú():
    print("a. Sube")
    print("b. Baja")
    print("c. Izquierda")
    print("d. Derecha")
    print("e. Salir")
    opción=input()
    return opción

#Variables globales
x=0
y=0
def MoverHaciaArriba(x,y):
    return x,y

def  MoverHaciaAbajo(x,y):
    return x,y

def MoverHaciaLaIzquierda(x,y):
    return x,y

def MoverHaciaLaDerecha(x,y):
    return x,y

match (menú()):
    case "a":
        print( "Estás en los puntos :",str(MoverHaciaArriba(x,1)))
    case "b":
        print( "Estás en los puntos :",str(MoverHaciaArriba(-1,y)))
    case "c":
        print( "Estás en los puntos :",str(MoverHaciaArriba(-1,y)))
    case "d":
        print( "Estás en los puntos :",str(MoverHaciaArriba(1,y)))
    case "e":
        print("Las coordenadas  finales del personaje son: “+X+”,”+Y")
